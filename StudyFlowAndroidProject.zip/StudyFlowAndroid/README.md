# StudyFlow Android app

This Android project wraps the StudyFlow web app in a native Android WebView container.

## Build an installable APK with Android Studio
1. Install Android Studio (with Android SDK Platform 35 and JDK 17).
2. Open this `StudyFlowAndroid` folder.
3. Wait for Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Build an APK online (without Android Studio)
1. Create a GitHub repository and upload the contents of this folder to it.
2. Open the repository's **Actions** tab.
3. Run **Build StudyFlow APK** (or push to `main` / `master`).
4. When the workflow completes, open the run and download the `StudyFlow-debug-apk` artifact.
5. Extract the downloaded ZIP; it contains `app-debug.apk`.

The workflow builds a debug APK. Android may ask you to allow installation from the browser or file manager. YouTube playback needs an internet connection.
